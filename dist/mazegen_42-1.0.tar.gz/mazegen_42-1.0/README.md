*The very first line must be italicized and read: This project has been created as part
of the 42 curriculum by sgarba, edraheim.*

# A-MAZE-ING-42

## Description
This is the "A-MAZE-ING" project from the 42 school.
The goal was to create a reuseable maze generator module and to wirte a program
that reads the configuration data from the cofig.txt file and creates a maze with the
maze generator module.
AMAZING is the root directory of the Project.
It contains: 
- the mazegen module in the mazegen directory
- the a_maze_ing.py file which contains the script to run the program
- the config.txt file where the maze configuration data is stored
- the LICENSE.md which contains the MIT licencse
- the pyproject.toml file to manage the packages
- the README.md which contains the documents
- the Makefile which contains the commands to run the program

## Instructions

If you want to intall the maze generator module in your project you have to add the mazegen module to your root directory first. Then run following the command  to build the package
```bash 
            pip install build --break-system-packages
            python3 -m build
```


## Resources

• The complete structure and format of your config file.
• The maze generation algorithm you chose.
• Why you chose this algorithm.
• What part of your code is reusable, and how.
• Your team and project management with:
◦ The roles of each team member.
◦ Your anticipated planning and how it evolved until the end
◦ What worked well and what could be improved
◦ Have you used any specific tools? Which ones?
If you implement advanced features (multiple algorithms, display options), describe them
in this README.md file.
English is recommended; alternatively, you may use the main language
of your campus